Matrix library (:mod:`numpy.matlib`)
************************************

.. currentmodule:: numpy

This module contains all functions in the :mod:`numpy` namespace, with
the following replacement functions that return :class:`matrices
<matrix>` instead of :class:`ndarrays <ndarray>`.

.. automodule:: numpy.matlib

