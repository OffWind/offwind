**********************************************
Numarray compatibility (:mod:`numpy.numarray`)
**********************************************

.. automodule:: numpy.numarray

